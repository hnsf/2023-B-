clear,clc
load data.mat
% figure(1)
% contour3(xdata,ydata,-zdata,'ShowText','on')
% hold on
% mesh(xdata,ydata,(-zdata));
y=linspace(0,1852*5,50);
x=linspace(0,1852*4,40);
p=[24.4 -0.007775 -0.00216 4.198e-06 9.33e-07 9.33e-07 -3.314e-16 -5.038e-10 -1.528e-15];
z_label=[];
c=[];
z=[];

for k = 1:40
    z_label=[];
    for jj=1:50
    i=x(k);
    j=y(jj);
    %z_label=[z_label (p(1)+p(2)*i+p(3)*j+p(4)*i*i+p(5)*i*j+p(6)*j*j+p(7)*i^3+p(8)*i*i*j+p(9)*i*j*j)/sqrt(3)];
    z_label=[z_label (p(1)+p(2)*i+p(3)*j+p(4)*i*i+p(5)*i*j+p(6)*j*j+p(7)*i^3+p(8)*i*i*j+p(9)*i*j*j)/sqrt(3)];
    end
    z=[z' z_label']';
end
%min(min(z))%11.5483
%  histogram(z)
%32.5 67.5 

% data=[c' z_label'];
% idx = dbscan(data,1,5);
% gscatter(data(:,1),data(:,2),idx);
ax=[];axx=[];ay=[];ayy=[];az=[];azz=[];bx=[];
bxx=[];by=[];byy=[];
bzz=[];bz=[];cx=[];cxx=[];cy=[];cyy=[];cz=[];czz=[];
add=[];bdd=[];cdd=[];
for i =1:50
%     axx=[];bxx=[];cxx=[];ayy=[];byy=[];cyy=[];
%     azz=[];bzz=[];czz=[];
    for j=1:40
        if z(j,i)>=67.5
            axx=[axx x(j)];ayy=[ayy y(i)];add=[add sqrt(x(j)^2+y(i)^2)];azz=[azz z(j,i)];
        elseif((32.5<=z(j,i))&&(z(j,i)<67.5))
            bxx=[bxx x(j)];byy=[byy y(i)];bdd=[bdd sqrt(x(j)^2+y(i)^2)];bzz=[bzz z(j,i)];
        elseif((0<z(j,i))&&(z(j,i)<=32.5))
            cxx=[cxx x(j)];cyy=[cyy y(i)];cdd=[cdd sqrt(x(j)^2+y(i)^2)];czz=[czz z(j,i)];
        end

    end
%     max(max(z))
%     min(min(z))
%     ax=[ax' axx']';bx=[bx' bxx']';cx=[cx' cxx']';
%     ay=[ay' ayy']';by=[by' byy']';cy=[cy' cyy']';
%     az=[az' azz']';bz=[bz' bzz']';cz=[cz' czz']';
end
%对第二类再分
 scatter(bxx,byy)
xie1=bxx(length(bxx))/byy(length(byy));
scatter(cxx,cyy)
% xie2=(cyy(1)-cyy(852))/2;
bxx1=[];byy1=[];bzz1=[];cxx1=[];cyy1=[];czz1=[];
bxx2=[];byy2=[];bzz2=[];cxx2=[];cyy2=[];czz2=[];
for i =1:1024
    if bxx(i)/byy(i)>xie1
        bxx1=[bxx1 bxx(i)];byy1=[byy1 byy(i)];bzz1=[bzz1 bzz(i)];
    else
        bxx2=[bxx2 bxx(i)];byy2=[byy2 byy(i)];bzz2=[bzz2 bzz(i)];
    end
end
% 
 scatter3(axx,ayy,-azz,'k')
 hold on
 scatter3(bxx1,byy1,-bzz1,'*')
 hold on
 scatter3(bxx2,byy2,-bzz2,'*')
 hold on
 scatter3(cxx,cyy,-czz,'.')
%进行搜索
%在第一类用坡度为0度，第二类用坡度为，第三类用坡度为
%第一类
%cef(axx,ayy,azz)
%z=-75.08+0.02512x-0.0102y
px=[100 200];%求第三类坡面的坡度
py=[100 200];
pz=-75.08+0.02512.*px-0.0102.*py;
aa=(pz(2)-pz(1))/sqrt((px(1)-px(2))^2+(py(1)-py(2))^2+(pz(2)-pz(1))^2);%sin
ab=sqrt((px(1)-px(2))^2+(py(1)-py(2))^2)/sqrt((px(1)-px(2))^2+(py(1)-py(2))^2+(pz(2)-pz(1))^2);%cos
ac=sind(30)*ab+cosd(30)*aa;
ad=sind(30)*ab-cosd(30)*aa;

%第二类，有点像双曲线的一边

%第三类，沿着等深线方向走
%cef(cxx,cyy,czz)
for i =1:124
if azz(i)==min(azz)
    fioxx=[axx];
    fioyy=[ayy];
    fiozz=[azz];
end
end

%沿着等深线走,达到重叠率10%,最浅处为11.5483米，覆盖宽度为11.5483*sqrt(3)米，按照
%重叠率10%，间隔为38.1227米，故此时的测线共有194条，根据第三类的占据最宽为 4.3688e+03米
%接着按照重叠率尽量控制在20%以下，那么通过改变测线的方向，确定重叠率，根据最深处的海深为113.8433米即
%只要确定当sin(斜坡)为aa处的向上的重叠率为20%的两个测线的间隔785，
% 间距为312.9695米)，那么至少可以确定第三类的x轴处的方向角与边界线的中间线段长为 53.1294 米
%通过改变原有的测线的中间线段长度，可减少测线的总长度，将每个方向角与边界线的中间线段长为
%并将分布测线表示出来

%第一类画测线
%最长处的x坐标为
mmin=[];
for i=1:852
    if cyy(i)==0
        mmin=[mmin cxx(i)];
    end
end
i=max(mmin);

j=max(ayy);%第一类水域的南北长
jj1=4381.57272000000;%第一类水域测线结束点
j2=min(bzz);%32.5121为第二类水域中的最浅
%计算使得第二类左海域的重叠率不大于20%的测线点
jj2=2*32.5121*sqrt(3);%覆盖宽度为112.6252米；
jjj2=ceil((5*1852-j)/jj2);%46个测线
%对于第二类右海域，也是同理，min(bzz2)为32.5121
jjj3=ceil(4*1852/jj2);%66个测线
c=linspace(0,5*1852,194);
%先将第一类海域和第二类海域的测线与x轴上的测线从靠近大数开始
a=linspace(0,4*1852,66);%66个测点
b1=linspace(5*1852,4381.57272000000,46);%46
b2=[0 312.96948	625.93896	938.90844	1251.87792	1564.8474	1877.81688	2190.78636	2503.75584	2816.72532 3129.6948 3442.66428	3755.63376	4068.60324	4381.57272];%第一类水域的测点分布
%关于d，分为2段，测点数：54,第一类水域和第三类水域,第一类水域( 1.5196e+03米，与y轴的第一类海域比为：
%0.3468)：5，第三类水域：62
d2=linspace((4*1852-1.5196e+03),0,62);
d1=4*1852.-[0 312.96948	625.93896	938.90844	1251.87792];%第一类水域的测点分布
kk=linspace(5*1852,0,194);

%求总测线长度
%对a的计算
long=0;
ee=[];
ee2=[];
eee2=[];
bx=[];
ax=[];
for i=2:66
    along=sqrt(a(i)^2+(5*1852-kk(i))^2);
    long=long+along;
    e1=polyfit([a(i),0],[5*1852,kk(i)],1);
    ee=[ee' e1']';
    if i<66
        aa=(a(i)+a(i+1))/2;
        bb=(kk(i)+kk(i+1))/2;
    ee2=polyfit([aa,0],[5*1852,bb],1);
    eee2=[eee2' ee2']';
    bx=[bx' [aa,0]']';
    end
ax=[ax' [a(i),0]']';
end
bx=[bx' [(a(66)+4*1852)/2,0]']';
ee2=polyfit([(a(66)+4*1852)/2,0],[(5*1852+b1(1))/2,(kk(66)+kk(67))/2],1);
eee2=[eee2' ee2']';
for i=1:46
    along=sqrt((4*1852)^2+(kk(i+66)-b1(i))^2);
    long=long+along;
    e2=polyfit([4*1852,0],[b1(i),kk(i+66)],1);
    ee=[ee' e2']';
  ax=[ax' [4*1852,0]']';  
    if i<46
        aa=(b1(i)+b1(i+1))/2;
        bb=(kk(i+66)+kk(i+67))/2;
    ee2=polyfit([4*1852,0],[aa,bb],1);
      eee2=[eee2' ee2']';
        bx=[bx' [4*1852,0]']';
    end
end
  ee2=polyfit([4*1852,0],[(b1(46)+b2(15))/2,(kk(46+66)+kk(46+67))/2],1);
  eee2=[eee2' ee2']';
  bx=[bx' [4*1852,0]']';


for i=1:15
    along=sqrt((4*1852)^2+(kk(i+66+46)-b2(16-i))^2);
    long=long+along;
    e3=polyfit([4*1852,0],[b2(16-i),kk(i+66+46)],1);
    ee=[ee' e3']';
   ax=[ax' [4*1852,0]']'; 
if i<15
    ee2=polyfit([4*1852,0],[(b2(16-i-1)+b2(16-i))/2,(kk(i+67+46)+kk(i+66+46))/2],1);
    eee2=[eee2' ee2']';
   bx=[bx' [4*1852,0]']'; 
end
end
    ee2=polyfit([4*1852,0],[(b2(16-14-1)+d1(1))/2,(kk(15+67+46)+kk(15+66+46))/2],1);
    eee2=[eee2' ee2']';
   bx=[bx' [4*1852,0]']'; 


for i=1:5
    long=long+sqrt(d1(i)^2+kk(i+66+46+15)^2)+long;
    e4=polyfit([d1(i),0],[0,kk(i+66+46+15)],1);
    ee=[ee' e4']';
    ax=[ax' [d1(i),0]']'; 
    if i<5
    ee2=polyfit([(d1(i)+d1(i+1))/2,0],[0,(kk(i+66+46+15)+kk(i+66+46+16))/2],1);
    eee2=[eee2' ee2']';
    bx=[bx' [(d1(i)+d1(i+1))/2,0]']'; 
    end

end


ee2=polyfit([(d1(5)+d2(1))/2,0],[0,(kk(5+66+46+15)+kk(5+66+46+16))/2],1);
eee2=[eee2' ee2']';
bx=[bx' [(d1(5)+d2(1))/2,0]']'; 

S=0;
for i=1:61
    long=long+sqrt(d2(i)^2+kk(i+66+46+15+5)^2);
    e5=polyfit([d2(i),0],[0,kk(i+66+46+15+5)],1);
    ee=[ee' e5']';
    ax=[ax' [d2(i),0]']'; 
    if i<61
    ee2=polyfit([(d2(i)+d2(i+1))/2,0],[0,(kk(i+66+46+15+5)+kk(i+66+46+15+6))/2],1);
    eee2=[ee2' ee2']';
    bx=[bx' [(d2(i)+d2(i+1))/2,0]']'; 
    end
end%最大深度为113.8433，最小深度为11.5483;

p=[24.4 -0.007775 -0.00216 4.198e-06 9.33e-07 9.33e-07 -3.314e-16 -5.038e-10 -1.528e-15];
for i =1:length(ee(:,2))
    si=abs(ee(i,1))/(abs(ee(i,1)+1));
    co=1/abs(ee(i,1));
fun = @(x,y) p(1)+p(2).*x+p(3).*y+p(4).*x.*x+p(5).*x.*y+p(6).*y.*y+p(7).*x.*x.*x+p(8).*x.*x.*y+p(9).*x.*y.*y;

ymin= @(x) ee(i,1)*(x+si*5)+ee(i,2)-co*5;
ymax = @(x) ee(i,1)*(x-si*5)+ee(i,2)+co*5;
q = abs(integral2(fun,ax(i,1),ax(i,2),ymin,ymax));
S=q+S;
end
baifen=100*S/4279967907.58338;
%用粗操的模型算覆盖率
%第一类海域：最浅处为：11.5483米，4381.57272000000
%算覆盖宽度
%第二类海域的坡度一致，最浅处为：32.5121米
%第三类海域的坡度最大，坡度的正弦为：0.0105494460980842等等
%对于第一类海域，如果出发时，重叠率未超过20%，则在第一海域都不会有超过20%的区域
%对于第二类海域，当海水深度为32.5121米时，利用sin(坡度)=0.048，cos(2.7513)= 0.9988
%sin(30+2.7513)=0.5410,sin(30-2.7513)=0.4579;
%因从各个方向坡度一致，在海的最低点时，故最大覆盖宽度为：2*sqrt(3)*20.9638=2*36.3104;
%根据测线的分布状况%66个测点，假设均匀分布，4381.5727/66=66.3875即覆盖宽度至多
%为66.3875；因此第二类海域有超过30%的重叠区域，接着计算当覆盖宽度为66.3875时，
%海水的高度：（66.3875/2）= 33.1938；33.1938/sqrt(3)=19.1644,即单个测线的
% 重叠长度为 13.3477，总的为 2*880.9482米，1.4949e+03米长度。
%接着计算第三类海域：求重叠率，采用第一问的模型算：有+15个测线且边界处的重叠率小于20%；
a11= 2*880.9482
