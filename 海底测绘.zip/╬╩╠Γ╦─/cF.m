function [fitresult, gof] = cF(xdata, ydata, zdata)
%CREATEFIT(XDATA,YDATA,ZDATA)
%  创建一个拟合。
%
%  要进行 '海底地形拟合 1' 拟合的数据:
%      X 输入: xdata
%      Y 输入: ydata
%      Z 输出: zdata
%  输出:
%      fitresult: 表示拟合的拟合对象。
%      gof: 带有拟合优度信息的结构体。
%
%  另请参阅 FIT, CFIT, SFIT.

%  由 MATLAB 于 09-Sep-2023 18:16:24 自动生成


%% 拟合: '海底地形拟合 1'。
[xData, yData, zData] = prepareSurfaceData( xdata, ydata, zdata );

% 设置 fittype 和选项。
ft = fittype( 'poly32' );

% 对数据进行模型拟合。
[fitresult, gof] = fit( [xData, yData], zData, ft );

% 绘制数据拟合图。
figure( 'Name', '海底地形拟合 1' );
h = plot( fitresult, [xData, yData], zData );
legend( h, '海底地形拟合 1', 'zdata vs. xdata, ydata', 'Location', 'NorthEast', 'Interpreter', 'none' );
% 为坐标区加标签
xlabel( 'xdata', 'Interpreter', 'none' );
ylabel( 'ydata', 'Interpreter', 'none' );
zlabel( 'zdata', 'Interpreter', 'none' );
grid on


